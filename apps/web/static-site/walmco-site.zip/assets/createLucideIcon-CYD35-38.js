import{r as i}from"./chunk-PVWAREVJ-D_rE8Vsp.js";if(typeof window<"u"){const r={};globalThis.process??={};const o=globalThis.process.env??{};globalThis.process.env=new Proxy(Object.assign({},r,o),{get(e,s){return s in e?e[s]:void 0},has(){return!0}})}/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var p={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};if(typeof window<"u"){const r={};globalThis.process??={};const o=globalThis.process.env??{};globalThis.process.env=new Proxy(Object.assign({},r,o),{get(e,s){return s in e?e[s]:void 0},has(){return!0}})}/**
 * @license lucide-react v0.358.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const h=r=>r.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase();if(typeof window<"u"){const r={};globalThis.process??={};const o=globalThis.process.env??{};globalThis.process.env=new Proxy(Object.assign({},r,o),{get(e,s){return s in e?e[s]:void 0},has(){return!0}})}const f=(r,o)=>{const e=i.forwardRef(({color:s="currentColor",size:n=24,strokeWidth:a=2,absoluteStrokeWidth:c,className:l="",children:t,...u},d)=>i.createElement("svg",{ref:d,...p,width:n,height:n,stroke:s,strokeWidth:c?Number(a)*24/Number(n):a,className:["lucide",`lucide-${h(r)}`,l].join(" "),...u},[...o.map(([b,g])=>i.createElement(b,g)),...Array.isArray(t)?t:[t]]));return e.displayName=`${r}`,e};export{f as c};
